# my_stdr_control

A simulation of making a robot run through a courseand publishing results

## Example usage
	
Run the maze and robot using: roslaunch stdr_launchers server_with_map_and_gui_plus_robot.launch 

Run the code to move the robot using: rosrun my_stdr_control my_stdr_open_loop_commander

## Running tests/demos
    
